-- ══════════════════════════════════════════════════════════════
-- 이룸덴탈랩 포털 v5.0 — Supabase 최종 설정 SQL
-- Supabase → SQL Editor → New Query → 전체 붙여넣기 → Run
-- ══════════════════════════════════════════════════════════════


-- ══════════════════════════════════════════════════════════════
-- 1단계: 기존 테이블 전체 삭제
-- ══════════════════════════════════════════════════════════════
DROP TABLE IF EXISTS production_log CASCADE;
DROP TABLE IF EXISTS cases CASCADE;
DROP TABLE IF EXISTS fixed_costs CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS clinics CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS prosthetics CASCADE;
DROP TABLE IF EXISTS settings CASCADE;


-- ══════════════════════════════════════════════════════════════
-- 2단계: 테이블 새로 생성 (id = text 타입)
-- ══════════════════════════════════════════════════════════════

-- users
CREATE TABLE users (
  id            text PRIMARY KEY,
  email         text,
  username      text UNIQUE,
  password_hash text,
  name          text,
  role          text DEFAULT 'clinic',
  clinic_id     text,
  created_at    timestamptz DEFAULT now()
);

-- clinics (custom_prices 포함)
CREATE TABLE clinics (
  id            text PRIMARY KEY,
  name          text NOT NULL,
  owner         text,
  owner_name    text,
  phone         text,
  email         text,
  address       text,
  discount_rate numeric DEFAULT 0,
  is_active     boolean DEFAULT true,
  custom_prices jsonb DEFAULT '{}'::jsonb,
  created_at    timestamptz DEFAULT now()
);

-- products
CREATE TABLE products (
  id            text PRIMARY KEY,
  name          text NOT NULL,
  selling_price integer DEFAULT 0,
  material_cost integer DEFAULT 0,
  unit          text DEFAULT '개',
  is_active     boolean DEFAULT true,
  is_deleted    boolean DEFAULT false,
  created_at    timestamptz DEFAULT now()
);

-- fixed_costs
CREATE TABLE fixed_costs (
  id         text PRIMARY KEY,
  name       text NOT NULL,
  amount     integer NOT NULL,
  category   text DEFAULT 'other',
  start_date date,
  end_date   date,
  is_active  boolean DEFAULT true,
  is_deleted boolean DEFAULT false,
  memo       text,
  created_at timestamptz DEFAULT now()
);

-- cases
CREATE TABLE cases (
  id            text PRIMARY KEY,
  case_number   text,
  clinic_id     text,
  clinic_name   text,
  patient_name  text,
  tooth_number  text,
  tooth_numbers text,
  tooth_count   integer DEFAULT 1,
  product_id    text,
  product_name  text,
  type          text,
  price         integer DEFAULT 0,
  discount_rate numeric DEFAULT 0,
  final_price   integer DEFAULT 0,
  status        text DEFAULT 'working',
  is_remake     boolean DEFAULT false,
  receive_date  date,
  ship_date     date,
  memo          text,
  history       jsonb DEFAULT '[]'::jsonb,
  created_at    timestamptz DEFAULT now()
);

-- production_log
CREATE TABLE production_log (
  id              text PRIMARY KEY,
  case_id         text,
  product_id      text,
  product_name    text,
  clinic_id       text,
  clinic_name     text,
  quantity        integer DEFAULT 1,
  selling_price   integer DEFAULT 0,
  material_cost   integer DEFAULT 0,
  final_price     integer DEFAULT 0,
  production_date date,
  memo            text,
  created_at      timestamptz DEFAULT now()
);


-- ══════════════════════════════════════════════════════════════
-- 3단계: RLS 활성화 + 전체 허용 정책
-- ══════════════════════════════════════════════════════════════

ALTER TABLE users          ENABLE ROW LEVEL SECURITY;
ALTER TABLE clinics         ENABLE ROW LEVEL SECURITY;
ALTER TABLE products        ENABLE ROW LEVEL SECURITY;
ALTER TABLE fixed_costs     ENABLE ROW LEVEL SECURITY;
ALTER TABLE cases           ENABLE ROW LEVEL SECURITY;
ALTER TABLE production_log  ENABLE ROW LEVEL SECURITY;

CREATE POLICY users_all          ON users          FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY clinics_all        ON clinics         FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY products_all       ON products        FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY fixed_costs_all    ON fixed_costs     FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY cases_all          ON cases           FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY production_log_all ON production_log  FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);


-- ══════════════════════════════════════════════════════════════
-- 완료 확인
-- ══════════════════════════════════════════════════════════════
SELECT '✅ 테이블 생성 + RLS 설정 + custom_prices 완료! 이제 홈페이지 배포하시면 됩니다.' as 결과;
